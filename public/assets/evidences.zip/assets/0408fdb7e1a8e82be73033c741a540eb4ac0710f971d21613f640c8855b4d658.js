window.customization = {};
window.customization.hideMobileQrCode = true;
